﻿program QueueStatic;

const
  MAX_SIZE = 10; // максимальный размер очереди (фактически храним MAX_SIZE-1 элементов)

type
  TQueue = record
    data: array[0..MAX_SIZE-1] of integer;
    head: integer; // индекс первого элемента
    tail: integer; // индекс следующего свободного места
  end;

var
  q: TQueue;

// Инициализация очереди
procedure InitQueue(var q: TQueue);
begin
  q.head := 0;
  q.tail := 0;
end;

// Проверка на пустоту
function IsEmpty(var q: TQueue): boolean;
begin
  IsEmpty := (q.head = q.tail);
end;

// Проверка на полноту
function IsFull(var q: TQueue): boolean;
begin
  IsFull := ((q.tail + 1) mod MAX_SIZE = q.head);
end;

// Добавление элемента
procedure Enqueue(var q: TQueue; value: integer);
begin
  if IsFull(q) then
    writeln('Очередь переполнена! Невозможно добавить элемент.')
  else
  begin
    q.data[q.tail] := value;
    q.tail := (q.tail + 1) mod MAX_SIZE;
    writeln('Элемент ', value, ' добавлен в очередь.');
  end;
end;

// Удаление элемента
function Dequeue(var q: TQueue): integer;
begin
  if IsEmpty(q) then
  begin
    writeln('Очередь пуста! Невозможно удалить элемент.');
    Dequeue := -1; // признак ошибки
  end
  else
  begin
    Dequeue := q.data[q.head];
    q.head := (q.head + 1) mod MAX_SIZE;
  end;
end;

// Визуализация очереди
procedure PrintQueue(var q: TQueue);
var
  i: integer;
begin
  writeln('Содержимое очереди (кольцевой буфер):');
  writeln('Индекс: ', ' ':2, '0 1 2 3 4 5 6 7 8 9');
  write  ('Значение:');
  for i := 0 to MAX_SIZE-1 do
  begin
    // Если ячейка содержит данные (между head и tail по кругу)
    if (q.head <= q.tail) and (i >= q.head) and (i < q.tail) or
       (q.head > q.tail) and ((i >= q.head) or (i < q.tail)) then
      write(q.data[i]:3)
    else
      write(' .':3);
  end;
  writeln;
  writeln('head -> ', q.head, '  tail -> ', q.tail);
  // Дополнительно: вывод элементов в порядке очереди
  if IsEmpty(q) then
    writeln('Очередь пуста.')
  else
  begin
    write('Элементы в порядке очереди: ');
    i := q.head;
    while i <> q.tail do
    begin
      write(q.data[i], ' ');
      i := (i + 1) mod MAX_SIZE;
    end;
    writeln;
  end;
end;

// Меню
procedure ShowMenu;
begin
  writeln;
  writeln('========== МЕНЮ ==========');
  writeln('1. Добавить элемент');
  writeln('2. Удалить элемент');
  writeln('3. Показать очередь');
  writeln('4. Очистить очередь');
  writeln('5. Выход');
  writeln('==========================');
  write('Выберите пункт: ');
end;

// Очистка очереди
procedure ClearQueue(var q: TQueue);
begin
  InitQueue(q);
  writeln('Очередь очищена.');
end;

var
  choice: integer;
  val: integer;
begin
  InitQueue(q);
  repeat
    ShowMenu;
    readln(choice);
    case choice of
      1: begin
           write('Введите целое число: ');
           readln(val);
           Enqueue(q, val);
         end;
      2: begin
           val := Dequeue(q);
           if val <> -1 then
             writeln('Удалён элемент: ', val);
         end;
      3: PrintQueue(q);
      4: ClearQueue(q);
      5: writeln('Программа завершена.');
      else writeln('Неверный пункт меню. Повторите ввод.');
    end;
  until choice = 5;
end.