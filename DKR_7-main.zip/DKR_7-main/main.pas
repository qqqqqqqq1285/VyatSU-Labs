﻿uses GraphABC, DragonCurve;

const
  BASE_STEP = 2.0;
  MAX_DEPTH = 18;
  VK_OEM_PLUS = 187;
  VK_OEM_MINUS = 189;
  VK_Z = 90;    // код клавиши Z
  VK_X = 88;    // код клавиши X

var
  depth: integer = 10;
  scale: real = 1.0;
  startX, startY: real;
  angle: real = 0.0;

procedure DrawScene;
var
  s: string;
begin
  ClearWindow(clWhite);
  SetPenColor(clBlack);
  DrawDragon(startX, startY, angle, BASE_STEP * scale, depth);
  SetFontColor(clRed);
  TextOut(10, 10, 'Depth: ' + depth.ToString);
  Str(scale:0:2, s);
  TextOut(10, 30, 'Scale: ' + s);
  TextOut(10, 50, 'Z/X zoom, +/- depth, arrows move, Home reset');
  Redraw;
end;

procedure KeyDown(key: integer);
begin
  case key of
    VK_ADD, VK_OEM_PLUS:        // + (цифровая и основная) — глубина
      if depth < MAX_DEPTH then depth := depth + 1;
    VK_SUBTRACT, VK_OEM_MINUS:  // - (цифровая и основная) — глубина
      if depth > 0 then depth := depth - 1;
    VK_Z: scale := scale * 1.2;  // Z — увеличение
    VK_X: scale := scale / 1.2;  // X — уменьшение
    VK_Left:  startX := startX - 10;
    VK_Right: startX := startX + 10;
    VK_Up:    startY := startY - 10;
    VK_Down:  startY := startY + 10;
    VK_Home:  begin
                scale := 1.0;
                startX := WindowWidth / 2;
                startY := WindowHeight / 2;
              end;
  end;
  DrawScene;
end;

begin
  SetWindowSize(800, 600);
  SetWindowCaption('Dragon Curve (Harter–Heighway)');
  LockDrawing;
  startX := WindowWidth / 2;
  startY := WindowHeight / 2;
  DrawScene;
  OnKeyDown := KeyDown;
end.