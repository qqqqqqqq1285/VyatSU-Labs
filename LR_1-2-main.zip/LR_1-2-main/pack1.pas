﻿program pack1;
var
  x1, y1, x2, y2: real;
  dx, dy, dist: real;
begin
  write('Введите x1: ');
  readln(x1);
  write('Введите y1: ');
  readln(y1);
  write('Введите x2: ');
  readln(x2);
  write('Введите y2: ');
  readln(y2);
  
  dx := x2 - x1;
  dy := y2 - y1;
  dist := sqrt(dx*dx + dy*dy);
  
  writeln('Расстояние: ', dist:0:2);
end.