import math

print('Введите x1: ')
x1 = float(input())
print('Введите y1: ')
y1 = float(input())
print('Введите x2: ')
x2 = float(input())
print('Введите y2: ')
y2 = float(input())

dx = x2 - x1
dy = y2 - y1
dist = math.sqrt(dx*dx + dy*dy)

print('Расстояние:', round(dist, 2))
