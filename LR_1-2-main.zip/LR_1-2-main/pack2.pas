﻿program pack2;
var
  n, a, b, c, rev, diff: integer;
begin
  write('Введите трехзначное число: ');
  readln(n);
  
  a := n div 100;
  b := (n div 10) mod 10;
  c := n mod 10;
  
  rev := c * 100 + b * 10 + a;
  diff := n - rev;
  
  writeln('Разность: ', diff);
end.