﻿program pack3;
var
  year: integer;
begin
  write('Введите год: ');
  readln(year);
  
  if ((year mod 4 = 0) and (year mod 100 <> 0)) or (year mod 400 = 0) then
    writeln('Високосный')
  else
    writeln('Не високосный');
end.