n = int(input('Введите трехзначное число: '))

a = n // 100
b = n // 10 % 10
c = n % 10

rev = c * 100 + b * 10 + a
diff = n - rev

print('Разность:', diff)
