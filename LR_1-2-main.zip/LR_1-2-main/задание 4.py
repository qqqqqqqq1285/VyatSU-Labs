print('Введите стоимость товара (рубли копейки):')
a, b = map(int, input().split())
print('Введите оплату (рубли копейки):')
c, d = map(int, input().split())

total_price = a * 100 + b
total_paid = c * 100 + d
change = total_paid - total_price

rub = change // 100
kop = change % 100

print('Сдача:', rub, 'руб.', kop, 'коп.')
