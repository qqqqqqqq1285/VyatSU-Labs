﻿program pack5;
var
  coord: string;
  letter, digit: char;
  sum: integer;
begin
  write('Введите координату клетки (например, A1): ');
  readln(coord);
  
  letter := coord[1];
  digit := coord[2];
  
  sum := ord(letter) + ord(digit);
  
  if sum mod 2 = 0 then
    writeln('BLACK')
  else
    writeln('WHITE');
end.