coord = input('Введите координату клетки (например, A1): ')

letter = coord[0]
digit = coord[1]

sum_val = ord(letter) + ord(digit)

if sum_val % 2 == 0:
    print('BLACK')
else:
    print('WHITE')
