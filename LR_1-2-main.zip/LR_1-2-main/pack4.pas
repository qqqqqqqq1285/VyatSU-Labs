﻿program pack4;
var
  a, b, c, d, total_price, total_paid, change: integer;
  rub, kop: integer;
begin
  write('Введите стоимость товара (рубли копейки): ');
  readln(a, b);
  write('Введите оплату (рубли копейки): ');
  readln(c, d);
  
  total_price := a * 100 + b;
  total_paid := c * 100 + d;
  change := total_paid - total_price;
  
  rub := change div 100;
  kop := change mod 100;
  
  writeln('Сдача: ', rub, ' руб. ', kop, ' коп.');
end.