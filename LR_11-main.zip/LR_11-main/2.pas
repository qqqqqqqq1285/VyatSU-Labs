﻿uses GraphABC;

begin
  Window.SetSize(600, 400);
  ClearWindow(clWhite);

 
  SetPenColor(clBlack);
  SetBrushColor(clRed);
  Circle(120, 200, 60);

  SetBrushColor(clYellow);
  Circle(480, 200, 60);

  SetBrushColor(clBlue);
  Polygon([(180,200), (300,80), (420,200)]);


  SetBrushColor(clLime);
  Polygon([(180,200), (300,320), (420,200)]);


  SetPenColor(clBlack);
  DrawPolygon([(180,200), (300,80), (420,200), (300,320)]);
end.
