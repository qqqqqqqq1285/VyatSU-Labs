﻿uses GraphABC;
var x,y:integer;
begin
  x:=100;
  y:=100;
    Window.SetSize(900, 450);
  ClearWindow(clWhite);
  while x <= 800 do
  begin
     SetPenColor(rgb(random(256), random(256), random(256)));
    SetBrushColor(rgb(random(256), random(256), random(256)));
    Circle(x,y,x div 10);
    x+=50;
    y+=20;
  end;
end.