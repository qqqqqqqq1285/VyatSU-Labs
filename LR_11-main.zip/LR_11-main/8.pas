﻿uses GraphABC;

var
  x, y, size: integer;

procedure DrawSquare(color: Color);
begin
  SetBrushColor(color);
  Rectangle(x, y, x + size, y + size);
end;

begin
  SetWindowSize(800, 600);
  size := 30;

  x := 100;
  y := 500;
  
  while (x < 400) and (y > 100) do
  begin
    DrawSquare(clBlack);
    x := x + 3;
    y := y - 4;
    DrawSquare(clWhite);
    Sleep(5);
  end;

  { вершина → справа вниз }
  while (x < 700) and (y < 500) do
  begin
    DrawSquare(clBlack);
    x := x + 3;
    y := y + 4;
    DrawSquare(clWhite);
    Sleep(5);
  end;

end.