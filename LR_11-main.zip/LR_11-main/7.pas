﻿uses GraphABC;
const
  N = 8;       
  CellSize = 50; 
var i,j:integer;
begin
  Window.SetSize(N*CellSize, N*CellSize);
  ClearWindow(clWhite);
  for i := 0 to N-1 do
    for j := 0 to N-1 do
    begin
      if (i + j) mod 2 = 0 then
        SetBrushColor(clWhite)
      else
        SetBrushColor(clBlack);
      Rectangle(i*CellSize, j*CellSize, (i+1)*CellSize, (j+1)*CellSize);
    end;
end.
