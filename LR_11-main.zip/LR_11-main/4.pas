﻿uses GraphABC;
var x:integer;
begin
  Window.SetSize(900, 450);
  ClearWindow(clWhite);
  x:=50;
  while x <=290 do
  begin
    SetPenColor(rgb(random(256), random(256), random(256)));
    SetBrushColor(rgb(random(256), random(256), random(256)));
    Circle(x, 100, 10);
    Inc(x, 30);
  end;
  
end.