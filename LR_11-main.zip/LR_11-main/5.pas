﻿uses GraphABC;

var
  i: integer;

begin
  Window.SetSize(900, 450);
  ClearWindow(clWhite);
  i := 1;
  while i <= 20 do
  begin
    SetPenColor(rgb(random(256), random(256), random(256)));
    SetBrushColor(rgb(random(256), random(256), random(256)));
    Circle(500, 200, random(200));
    i += 1;
  end;
end.