﻿uses GraphABC;
procedure Square(x, y, side: Integer; color: Color);
begin
  SetPenColor(color);
  MoveTo(x, y);
  LineTo(x + side, y);
  LineTo(x + side, y + side);
  LineTo(x, y + side);
  LineTo(x, y);
end;
procedure Triangular(x, y, side: Integer; color: Color);
var
  x2, y2: Integer;
begin
  SetPenColor(color);
  MoveTo(x, y);
  LineTo(x + side, y);
  x2 := x + side div 2;
  y2 := y - Round(side * Sin(Pi / 3));
  LineTo(x2, y2);
  LineTo(x, y);
end;
begin
  ClearWindow;
  Square(100, 100, 100, clBlue);
  Triangular(300, 200, 100, clRed);
  ReadLn;
end.