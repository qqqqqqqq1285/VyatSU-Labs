﻿uses GraphABC;

begin
  Window.SetSize(900, 450);
  ClearWindow(clWhite);


  SetPenColor(clBlack);
  SetBrushColor(clBlue);
  Polygon([(200,420), (180,120), (400,420)]);
  SetBrushColor(clBlue);
  Circle(180, 120, 50);


  SetBrushColor(clLime);
  Polygon([(500,420), (700,120), (670,420)]);
  SetBrushColor(clLime);
  Circle(700, 120, 50);
  
 
  SetBrushColor(clRed);
  Polygon([(300,420), (450,60), (580,420)]);
  SetBrushColor(clRed);
  Circle(450, 60, 50);
end.
