﻿program Lab1Task2;
var
x, y: real;
f: text;
begin
assign(f, 'result.txt');
rewrite(f);

x := -9.0;
while x <= 8.0 do
begin
if x < -7 then
y := x * (0.1 + x) - cos(x)
else if (x > -7) and (x < -3) then
begin
if (x > 0) and (x <> 1) then
y := 9 * x * (0.1 + x) - x / ln(x)
else
y := 0;
end
else if (x > -3) and (x < 6) then
begin
if x <> 0 then
y := x / x + exp(x)
else
y := 0;
end
else if x > 6 then
begin
if cos(x) <> 0 then
y := 5 / cos(x) - 71
else
y := 0;
end
else
y := 0;

writeln('x = ', x:5:1, ' y = ', y:8:4);
writeln(f, 'x = ', x:5:1, ' y = ', y:8:4);
x := x + 0.1;
end;

close(f);
writeln('Результаты в файле result.txt');
readln;
end.