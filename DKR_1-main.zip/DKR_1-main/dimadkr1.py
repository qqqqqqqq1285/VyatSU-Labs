import math

with open('result.txt', 'w', encoding='utf-8') as f:
x = -9.0
while x <= 8.0:
if x < -7:
y = x * (0.1 + x) - math.cos(x)
elif -7 < x < -3:
if x > 0 and x != 1:
y = 9 * x * (0.1 + x) - x / math.log(x)
else:
y = 0
elif -3 < x < 6:
if x != 0:
y = x / x + math.exp(x)
else:
y = 0
elif x > 6:
if math.cos(x) != 0:
y = 5 / math.cos(x) - 71
else:
y = 0
else:
y = 0

line = f'x = {x:5.1f} y = {y:8.4f}'
print(line)
f.write(line + '\n')

x += 0.1

print('Результаты в файле result.txt')
input()
