import math

x = float(input('Введите x: '))

if x < -7:
y = x * (0.1 + x) - math.cos(x)
elif -7 < x < -3:
if x > 0 and x != 1:
y = 9 * x * (0.1 + x) - x / math.log(x)
else:
y = 0
elif -3 < x < 6:
if x != 0:
y = x / x + math.exp(x)
else:
y = 0
elif x > 6:
if math.cos(x) != 0:
y = 5 / math.cos(x) - 71
else:
y = 0
else:
y = 0

print(f'y = {y:.4f}')
