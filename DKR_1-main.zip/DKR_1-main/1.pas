﻿program Lab1Task1;
var
x, y: real;
begin
write('Введите x: ');
readln(x);

if x < -7 then
y := x * (0.1 + x) - cos(x)
else if (x > -7) and (x < -3) then
begin
if (x > 0) and (x <> 1) then
y := 9 * x * (0.1 + x) - x / ln(x)
else
y := 0;
end
else if (x > -3) and (x < 6) then
begin
if x <> 0 then
y := x / x + exp(x)
else
y := 0;
end
else if x > 6 then
begin
if cos(x) <> 0 then
y := 5 / cos(x) - 71
else
y := 0;
end
else
y := 0;

writeln('y = ', y:0:4);
readln;
end.